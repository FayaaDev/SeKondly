import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  password: text("password"),
  specialty: text("specialty").notNull(),
  experience: text("experience").notNull(),
  avatar: text("avatar"),

  // Board Certification
  boardCertification: text("board_certification"),
  certificationYear: text("certification_year"),

  // Fellowship
  fellowship: text("fellowship"),
  fellowshipYear: text("fellowship_year"),

  // Profile status
  isOnboarded: integer("is_onboarded").notNull().default(0),
  isVerified: integer("is_verified").notNull().default(0), // 0 = pending, 1 = verified, 2 = rejected
  isBanned: integer("is_banned").notNull().default(0), // 0 = active, 1 = banned
  isAdmin: integer("is_admin").notNull().default(0), // 0 = user, 1 = admin

  // Document verification
  credentialsUrl: text("credentials_url"),
  credentialsStatus: text("credentials_status").default("pending"), // pending, approved, rejected
  credentialsRejectReason: text("credentials_reject_reason"),

  createdAt: timestamp("created_at").defaultNow(),
});

export const cases = pgTable("cases", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  history: text("history"),
  challenges: text("challenges"),
  priority: text("priority").notNull().default("routine"), // routine, urgent, critical
  imageUrl: text("image_url"),
  authorId: integer("author_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  likesCount: integer("likes_count").notNull().default(0),
  commentsCount: integer("comments_count").notNull().default(0),
  viewsCount: integer("views_count").notNull().default(0),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  caseId: integer("case_id").notNull(),
  authorId: integer("author_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  likesCount: integer("likes_count").notNull().default(0),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // comment, like, mention
  message: text("message").notNull(),
  userId: integer("user_id").notNull(),
  caseId: integer("case_id"),
  commentId: integer("comment_id"),
  isRead: integer("is_read").notNull().default(0), // 0 = false, 1 = true
  createdAt: timestamp("created_at").defaultNow(),
});

export const caseImages = pgTable("case_images", {
  id: serial("id").primaryKey(),
  caseId: integer("case_id").notNull(),
  imageUrl: text("image_url").notNull(),
  caption: text("caption"),
  orderIndex: integer("order_index").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  name: true,
  email: true,
  phone: true,
  specialty: true,
  experience: true,
  avatar: true,
  boardCertification: true,
  certificationYear: true,
  fellowship: true,
  fellowshipYear: true,
});

export const onboardingUserSchema = createInsertSchema(users).pick({
  username: true,
  name: true,
  email: true,
  phone: true,
  password: true,
  specialty: true,
  experience: true,
  boardCertification: true,
  fellowship: true,
  credentialsUrl: true,
  credentialsStatus: true,
  credentialsRejectReason: true,
});

export const insertCaseSchema = createInsertSchema(cases).pick({
  title: true,
  history: true,
  challenges: true,
  priority: true,
  imageUrl: true,
  authorId: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  content: true,
  caseId: true,
  authorId: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  type: true,
  message: true,
  userId: true,
  caseId: true,
  commentId: true,
});

export const insertCaseImageSchema = createInsertSchema(caseImages).pick({
  caseId: true,
  imageUrl: true,
  caption: true,
  orderIndex: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Case = typeof cases.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertCaseImage = z.infer<typeof insertCaseImageSchema>;
export type CaseImage = typeof caseImages.$inferSelect;

export type CaseWithAuthor = Case & {
  author: User;
};

export type CaseWithImages = Case & {
  author: User;
  images: CaseImage[];
};

export type CommentWithAuthor = Comment & {
  author: User;
};

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  cases: many(cases),
  comments: many(comments),
  notifications: many(notifications),
}));

export const casesRelations = relations(cases, ({ one, many }) => ({
  author: one(users, {
    fields: [cases.authorId],
    references: [users.id],
  }),
  comments: many(comments),
  images: many(caseImages),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  author: one(users, {
    fields: [comments.authorId],
    references: [users.id],
  }),
  case: one(cases, {
    fields: [comments.caseId],
    references: [cases.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  case: one(cases, {
    fields: [notifications.caseId],
    references: [cases.id],
  }),
  comment: one(comments, {
    fields: [notifications.commentId],
    references: [comments.id],
  }),
}));

export const caseImagesRelations = relations(caseImages, ({ one }) => ({
  case: one(cases, {
    fields: [caseImages.caseId],
    references: [cases.id],
  }),
}));
