import { useState } from "react";
import { Search, User, Edit3, Bell, Shield, ChevronRight, LogOut } from "lucide-react";
import { Link } from "wouter";

export default function AppHeader() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const closeDropdown = () => {
    setIsDropdownOpen(false);
  };

  const handleSignOut = () => {
    // Clear any stored authentication data
    localStorage.removeItem('authToken');
    sessionStorage.clear();
    
    // Redirect to login/onboarding page
    window.location.href = '/onboarding';
    closeDropdown();
  };

  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-40">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-gray-900">MedShare</h1>
        <div className="flex items-center space-x-3">
          <Search className="h-5 w-5 clinical-gray cursor-pointer" />
          <div className="relative">
            <div 
              className="w-8 h-8 bg-medical-blue rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-600 transition-colors"
              onClick={toggleDropdown}
            >
              <User className="h-4 w-4 text-white" />
            </div>
            
            {isDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={closeDropdown}
                />
                <div className="absolute right-0 top-10 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-20">
                  <div className="p-2">
                    <Link href="/profile/edit" onClick={closeDropdown}>
                      <div className="flex items-center p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                          <Edit3 className="h-5 w-5 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">Edit Profile</h3>
                          <p className="text-sm text-gray-500">Update your professional information</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                      </div>
                    </Link>
                    
                    <Link href="/settings/notifications" onClick={closeDropdown}>
                      <div className="flex items-center p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                          <Bell className="h-5 w-5 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">Notifications</h3>
                          <p className="text-sm text-gray-500">Manage notification preferences</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                      </div>
                    </Link>
                    
                    <Link href="/settings/privacy" onClick={closeDropdown}>
                      <div className="flex items-center p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                          <Shield className="h-5 w-5 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">Privacy & Security</h3>
                          <p className="text-sm text-gray-500">Control your privacy settings</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                      </div>
                    </Link>
                    
                    <div className="border-t border-gray-100 my-2"></div>
                    
                    <button onClick={handleSignOut} className="w-full">
                      <div className="flex items-center p-3 rounded-lg hover:bg-red-50 cursor-pointer transition-colors">
                        <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mr-3">
                          <LogOut className="h-5 w-5 text-red-600" />
                        </div>
                        <div className="flex-1 text-left">
                          <h3 className="font-semibold text-red-900">Sign Out</h3>
                          <p className="text-sm text-red-600">Sign out of your account</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
