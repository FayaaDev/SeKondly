import { useVerification } from "@/hooks/use-verification";
import { useLocation } from "wouter";

interface VerificationGuardProps {
  children: React.ReactNode;
}

export function VerificationGuard({ children }: VerificationGuardProps) {
  const [location] = useLocation();
  const { isLoading, needsVerification, needsOnboarding } = useVerification();

  // Allow access to certain pages without verification
  const allowedPages = ["/onboarding", "/pending-verification", "/admin"];
  const isAllowedPage = allowedPages.some(page => location.startsWith(page));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Don't render guard for allowed pages
  if (isAllowedPage) {
    return <>{children}</>;
  }

  // Redirect to onboarding if needed
  if (needsOnboarding) {
    return null; // useVerification hook handles the redirect
  }

  // Redirect to pending verification if needed
  if (needsVerification) {
    return null; // useVerification hook handles the redirect
  }

  return <>{children}</>;
}