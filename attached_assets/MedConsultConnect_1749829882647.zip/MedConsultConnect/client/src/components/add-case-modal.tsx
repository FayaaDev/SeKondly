import { useState } from "react";
import { X, Upload, CloudUpload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface AddCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddCaseModal({ isOpen, onClose }: AddCaseModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    history: "",
    challenges: "",
    priority: "routine"
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createCaseMutation = useMutation({
    mutationFn: (data: FormData) => api.createCase(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
      toast({
        title: "Case shared successfully",
        description: "Your medical case has been posted for colleague review.",
      });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to share case. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setFormData({ title: "", history: "", challenges: "", priority: "routine" });
    setSelectedFile(null);
    setPreviewUrl(null);
    onClose();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast({
        title: "Error",
        description: "Please provide a case title.",
        variant: "destructive",
      });
      return;
    }

    const submitData = new FormData();
    submitData.append("title", formData.title);
    submitData.append("history", formData.history);
    submitData.append("challenges", formData.challenges);
    submitData.append("priority", formData.priority);
    
    if (selectedFile) {
      submitData.append("image", selectedFile);
    }

    createCaseMutation.mutate(submitData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end">
      <div className="bg-white w-full max-w-md mx-auto rounded-t-3xl flex flex-col h-[90vh] transform transition-transform duration-300">
        <div className="flex items-center justify-between p-6 pb-4 border-b border-gray-100 flex-shrink-0">
          <h3 className="text-xl font-bold text-gray-900">Share a Case</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClose}
            className="w-8 h-8 bg-gray-100 rounded-full"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="title" className="text-sm font-medium text-gray-900">
                Case Title *
              </Label>
              <Input
                id="title"
                placeholder="Brief description of the case..."
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="mt-2"
                required
              />
            </div>

            <div>
              <Label htmlFor="history" className="text-sm font-medium text-gray-900">
                Patient History
              </Label>
              <Textarea
                id="history"
                placeholder="Relevant medical history, symptoms, etc..."
                rows={3}
                value={formData.history}
                onChange={(e) => setFormData({ ...formData, history: e.target.value })}
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="challenges" className="text-sm font-medium text-gray-900">
                Challenges & Questions
              </Label>
              <Textarea
                id="challenges"
                placeholder="What specific challenges are you facing? What questions do you have?"
                rows={3}
                value={formData.challenges}
                onChange={(e) => setFormData({ ...formData, challenges: e.target.value })}
                className="mt-2"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-900">Upload Images</Label>
              <div className="mt-2">
                <label className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-blue-400 transition-colors block">
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                  {previewUrl ? (
                    <div className="space-y-2">
                      <img 
                        src={previewUrl} 
                        alt="Preview" 
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <p className="text-sm text-gray-600">Click to change image</p>
                    </div>
                  ) : (
                    <>
                      <CloudUpload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">Tap to upload medical images</p>
                      <p className="text-sm clinical-gray mt-1">PNG, JPG up to 10MB</p>
                    </>
                  )}
                </label>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-900">Priority Level</Label>
              <RadioGroup
                value={formData.priority}
                onValueChange={(value) => setFormData({ ...formData, priority: value })}
                className="mt-2"
              >
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "routine", label: "Routine" },
                    { value: "urgent", label: "Urgent" },
                    { value: "critical", label: "Critical" }
                  ].map((option) => (
                    <div key={option.value} className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-gray-50">
                      <RadioGroupItem value={option.value} id={option.value} />
                      <Label htmlFor={option.value} className="text-sm cursor-pointer">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
        </div>
        
        <div className="p-6 border-t border-gray-100 bg-white">
          <Button 
            onClick={handleSubmit}
            className="w-full bg-medical-blue hover:bg-blue-600 h-12 text-white font-semibold"
            disabled={createCaseMutation.isPending}
          >
            {createCaseMutation.isPending ? "Sharing..." : "Share Case"}
          </Button>
        </div>
      </div>
    </div>
  );
}
