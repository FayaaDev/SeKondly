import { useState } from "react";
import { ArrowLeft, MessageCircle, Heart, Eye, Send, Image, Paperclip } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { CaseWithAuthor, CommentWithAuthor } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface CaseDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseId: number | null;
}

export default function CaseDetailModal({ isOpen, onClose, caseId }: CaseDetailModalProps) {
  const [commentText, setCommentText] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: caseData, isLoading: caseLoading } = useQuery({
    queryKey: ["/api/cases", caseId],
    queryFn: () => caseId ? api.getCase(caseId) : null,
    enabled: isOpen && !!caseId,
  });

  const { data: comments = [], isLoading: commentsLoading } = useQuery({
    queryKey: ["/api/cases", caseId, "comments"],
    queryFn: () => caseId ? api.getCaseComments(caseId) : [],
    enabled: isOpen && !!caseId,
  });

  const addCommentMutation = useMutation({
    mutationFn: (content: string) => caseId ? api.createComment(caseId, content) : Promise.reject(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases", caseId, "comments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
      setCommentText("");
      toast({
        title: "Response posted",
        description: "Your response has been added to the case.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to post response. Please try again.",
        variant: "destructive",
      });
    },
  });

  const likeCommentMutation = useMutation({
    mutationFn: (commentId: number) => api.likeComment(commentId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases", caseId, "comments"] });
    },
  });

  const handleCommentSubmit = () => {
    if (!commentText.trim()) return;
    addCommentMutation.mutate(commentText);
  };

  const formatTimeAgo = (date: Date | string) => {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now.getTime() - past.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays}d ago`;
    if (diffHours > 0) return `${diffHours}h ago`;
    if (diffMinutes > 0) return `${diffMinutes}m ago`;
    return "now";
  };

  const getPriorityInfo = (priority: string) => {
    switch (priority) {
      case "urgent":
        return { label: "Urgent", bgColor: "bg-medical-blue", textColor: "text-white" };
      case "critical":
        return { label: "Critical", bgColor: "bg-medical-red", textColor: "text-white" };
      default:
        return { label: "Routine", bgColor: "bg-gray-500", textColor: "text-white" };
    }
  };

  const getSpecialtyColor = (specialty: string) => {
    const colors = [
      "bg-medical-green",
      "bg-medical-blue", 
      "bg-purple-500",
      "bg-indigo-500",
      "bg-pink-500",
      "bg-orange-500"
    ];
    return colors[specialty.length % colors.length];
  };

  if (!isOpen) return null;

  if (caseLoading) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading case details...</p>
        </div>
      </div>
    );
  }

  if (!caseData) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Case not found</p>
          <Button onClick={onClose} className="mt-4">Go Back</Button>
        </div>
      </div>
    );
  }

  const priority = getPriorityInfo(caseData.priority);

  return (
    <div className="fixed inset-0 bg-white z-50 transform transition-transform duration-300">
      <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="mr-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h2 className="text-lg font-semibold text-gray-900">Case Details</h2>
      </header>

      <div className="flex-1 overflow-y-auto p-4 pb-24">
        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <Link href={`/doctor/${caseData.author.id}`}>
              <div className={`w-12 h-12 ${getSpecialtyColor(caseData.author.specialty)} rounded-full flex items-center justify-center hover:opacity-80 transition-opacity cursor-pointer`}>
                <span className="text-white font-semibold">
                  {caseData.author.name.split(' ')[1]?.[0] || 'D'}
                </span>
              </div>
            </Link>
            <div>
              <Link 
                href={`/doctor/${caseData.author.id}`}
                className="font-semibold text-gray-900 hover:text-medical-blue transition-colors"
              >
                {caseData.author.name}
              </Link>
              <p className="text-sm clinical-gray">{caseData.author.specialty} • {formatTimeAgo(caseData.createdAt!)}</p>
            </div>
          </div>

          <h1 className="text-xl font-bold text-gray-900 mb-3">{caseData.title}</h1>

          <div className="flex items-center space-x-2 mb-4">
            <span className={`${priority.bgColor} ${priority.textColor} px-3 py-1 rounded-full text-sm font-medium`}>
              {priority.label}
            </span>
            <span className="clinical-gray text-sm">•</span>
            <span className="clinical-gray text-sm">{caseData.author.specialty}</span>
          </div>
        </div>

        {caseData.imageUrl && (
          <div className="mb-6">
            <img 
              src={caseData.imageUrl} 
              alt={`Medical case: ${caseData.title}`}
              className="w-full rounded-xl" 
            />
          </div>
        )}

        <div className="space-y-4 mb-6">
          {caseData.history && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Patient History</h4>
              <p className="text-gray-700">{caseData.history}</p>
            </div>
          )}

          {caseData.challenges && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Challenges & Questions</h4>
              <p className="text-gray-700">{caseData.challenges}</p>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-6 py-4 border-y border-gray-200 mb-6">
          <div className="flex items-center space-x-2 clinical-gray">
            <MessageCircle className="h-4 w-4" />
            <span className="text-sm">{caseData.commentsCount} responses</span>
          </div>
          <div className="flex items-center space-x-2 clinical-gray">
            <Heart className="h-4 w-4" />
            <span className="text-sm">{caseData.likesCount} likes</span>
          </div>
          <div className="flex items-center space-x-2 clinical-gray">
            <Eye className="h-4 w-4" />
            <span className="text-sm">{caseData.viewsCount} views</span>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Responses from Colleagues</h4>

          {commentsLoading ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-600">Loading responses...</p>
            </div>
          ) : comments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <MessageCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No responses yet. Be the first to share your thoughts!</p>
            </div>
          ) : (
            comments.map((comment: CommentWithAuthor) => (
              <div key={comment.id} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-3">
                  <Link href={`/doctor/${comment.author.id}`}>
                    <div className={`w-8 h-8 ${getSpecialtyColor(comment.author.specialty)} rounded-full flex items-center justify-center hover:opacity-80 transition-opacity cursor-pointer`}>
                      <span className="text-white text-xs font-semibold">
                        {comment.author.name.split(' ')[1]?.[0] || 'D'}
                      </span>
                    </div>
                  </Link>
                  <div>
                    <Link 
                      href={`/doctor/${comment.author.id}`}
                      className="font-semibold text-gray-900 hover:text-medical-blue transition-colors"
                    >
                      {comment.author.name}
                    </Link>
                    <span className="text-sm clinical-gray ml-2">
                      {comment.author.specialty} • {formatTimeAgo(comment.createdAt!)}
                    </span>
                  </div>
                </div>
                <p className="text-gray-700 mb-3">{comment.content}</p>
                <div className="flex items-center space-x-4 clinical-gray text-sm">
                  <button 
                    className="flex items-center space-x-1 hover:text-red-500 transition-colors"
                    onClick={() => likeCommentMutation.mutate(comment.id)}
                    disabled={likeCommentMutation.isPending}
                  >
                    <Heart className="h-4 w-4" />
                    <span>{comment.likesCount}</span>
                  </button>
                  <button className="hover:text-blue-500 transition-colors">Reply</button>
                </div>
              </div>
            ))
          )}

          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <Textarea
              placeholder="Share your thoughts on this case..."
              rows={3}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              className="mb-3 border-gray-300 focus:border-blue-500"
            />
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3 clinical-gray">
                <button className="hover:text-blue-500 transition-colors">
                  <Image className="h-5 w-5" />
                </button>
                <button className="hover:text-blue-500 transition-colors">
                  <Paperclip className="h-5 w-5" />
                </button>
              </div>
              <Button 
                onClick={handleCommentSubmit}
                disabled={!commentText.trim() || addCommentMutation.isPending}
                className="bg-medical-blue hover:bg-blue-600"
              >
                {addCommentMutation.isPending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                Post Response
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
