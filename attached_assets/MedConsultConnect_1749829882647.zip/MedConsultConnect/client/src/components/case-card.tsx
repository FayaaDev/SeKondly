import { MessageCircle, Heart, Share, Clock, AlertTriangle, Stethoscope, Eye } from "lucide-react";
import type { CaseWithAuthor } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Link } from "wouter";

interface CaseCardProps {
  case: CaseWithAuthor;
  onClick: () => void;
}

export default function CaseCard({ case: caseData, onClick }: CaseCardProps) {
  const queryClient = useQueryClient();

  // Add null check for case data and author
  if (!caseData || !caseData.author) {
    return null;
  }

  const likeMutation = useMutation({
    mutationFn: () => api.likeCase(caseData.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cases"] });
    },
  });

  const formatTimeAgo = (date: Date | string) => {
    const now = new Date();
    const past = new Date(date);
    const diffMs = now.getTime() - past.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays}d`;
    if (diffHours > 0) return `${diffHours}h`;
    return "now";
  };

  const getPriorityInfo = (priority: string) => {
    switch (priority) {
      case "urgent":
        return { icon: Stethoscope, label: "Urgent", color: "medical-blue" };
      case "critical":
        return { icon: AlertTriangle, label: "Critical", color: "medical-red" };
      default:
        return { icon: Clock, label: "Routine", color: "clinical-gray" };
    }
  };

  const getSpecialtyColor = (specialty: string) => {
    const colors = [
      "bg-medical-green",
      "bg-medical-blue", 
      "bg-purple-500",
      "bg-indigo-500",
      "bg-pink-500",
      "bg-orange-500"
    ];
    return colors[specialty.length % colors.length];
  };

  const priority = getPriorityInfo(caseData.priority);
  const PriorityIcon = priority.icon;

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    likeMutation.mutate();
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Share functionality would be implemented here
  };

  return (
    <article 
      className="bg-white border-b border-gray-100 p-4 cursor-pointer hover:bg-gray-50 transition-colors"
      onClick={onClick}
    >
      <div className="flex space-x-3">
        <Link 
          href={`/doctor/${caseData.author.id}`}
          onClick={(e) => e.stopPropagation()}
          className="flex-shrink-0"
        >
          <div className={`w-10 h-10 ${getSpecialtyColor(caseData.author.specialty)} rounded-full flex items-center justify-center hover:opacity-80 transition-opacity cursor-pointer`}>
            <span className="text-white text-sm font-semibold">
              {caseData.author.name.split(' ')[1]?.[0] || 'D'}
            </span>
          </div>
        </Link>
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <Link 
              href={`/doctor/${caseData.author.id}`}
              className="font-semibold text-gray-900 hover:text-medical-blue transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              {caseData.author.name}
            </Link>
            <span className="text-sm clinical-gray">{caseData.author.specialty}</span>
            <span className="text-sm clinical-gray">•</span>
            <span className="text-sm clinical-gray">{formatTimeAgo(caseData.createdAt!)}</span>
          </div>
          
          <h3 className="text-gray-900 font-medium mb-2">{caseData.title}</h3>
          
          {caseData.imageUrl && (
            <div className="mt-3 rounded-xl overflow-hidden">
              <img 
                src={caseData.imageUrl} 
                alt={`Medical case: ${caseData.title}`}
                className="w-full h-48 object-cover" 
              />
            </div>
          )}
          
          <div className="flex items-center justify-between mt-3 clinical-gray">
            <div className="flex items-center space-x-4">
              <button 
                className="flex items-center space-x-1 hover:text-blue-500 transition-colors"
                onClick={(e) => {
                  e.stopPropagation();
                  onClick();
                }}
              >
                <MessageCircle className="h-4 w-4" />
                <span className="text-sm">{caseData.commentsCount}</span>
              </button>
              
              <button 
                className="flex items-center space-x-1 hover:text-red-500 transition-colors"
                onClick={handleLike}
                disabled={likeMutation.isPending}
              >
                <Heart className="h-4 w-4" />
                <span className="text-sm">{caseData.likesCount}</span>
              </button>
              
              <button 
                className="flex items-center space-x-1 hover:text-blue-500 transition-colors"
                onClick={handleShare}
              >
                <Share className="h-4 w-4" />
              </button>
              
              <div className="flex items-center space-x-1 text-xs">
                <Eye className="h-3 w-3" />
                <span>{caseData.viewsCount}</span>
              </div>
            </div>
            
            <div className={`flex items-center space-x-1 ${priority.color}`}>
              <PriorityIcon className="h-4 w-4" />
              <span className="text-sm">{priority.label}</span>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}
