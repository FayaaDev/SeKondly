import { apiRequest } from "./queryClient";
import type { CaseWithAuthor, CommentWithAuthor } from "@shared/schema";

export const api = {
  // Cases
  getCases: (): Promise<CaseWithAuthor[]> =>
    fetch("/api/cases", { credentials: "include" }).then(res => res.json()),
    
  getCase: (id: number): Promise<CaseWithAuthor> =>
    fetch(`/api/cases/${id}`, { credentials: "include" }).then(res => res.json()),
    
  getMyCases: (): Promise<CaseWithAuthor[]> =>
    fetch("/api/my-cases", { credentials: "include" }).then(res => res.json()),
    
  createCase: async (data: FormData): Promise<any> => {
    const response = await fetch("/api/cases", {
      method: "POST",
      body: data,
      credentials: "include",
    });
    return response.json();
  },
  
  likeCase: (id: number) =>
    apiRequest("POST", `/api/cases/${id}/like`),
    
  // Comments
  getCaseComments: (caseId: number): Promise<CommentWithAuthor[]> =>
    fetch(`/api/cases/${caseId}/comments`, { credentials: "include" }).then(res => res.json()),
    
  createComment: (caseId: number, content: string) =>
    apiRequest("POST", `/api/cases/${caseId}/comments`, { content }),
    
  likeComment: (id: number) =>
    apiRequest("POST", `/api/comments/${id}/like`),
    
  // Profile
  getProfile: () =>
    fetch("/api/profile", { credentials: "include" }).then(res => res.json()),
    
  // Notifications
  getNotifications: () =>
    fetch("/api/notifications", { credentials: "include" }).then(res => res.json()),
};
