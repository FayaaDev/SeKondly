import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";

interface UserStatus {
  isVerified: number;
  isBanned: number;
  credentialsStatus: string;
  isOnboarded: number;
}

export function useVerification() {
  const [, setLocation] = useLocation();
  
  const { data: userStatus, isLoading, error } = useQuery<UserStatus | null>({
    queryKey: ["/api/user/status"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/user/status", { credentials: "include" });
        if (res.status === 400 || res.status === 401) {
          return null;
        }
        if (!res.ok) {
          throw new Error("Failed to fetch user status");
        }
        return await res.json();
      } catch (error) {
        return null;
      }
    },
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchInterval: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  useEffect(() => {
    if (!isLoading && userStatus) {
      // Check if user is not onboarded
      if (!userStatus.isOnboarded) {
        setLocation("/onboarding");
        return;
      }
      
      // Check if user is banned
      if (userStatus.isBanned) {
        // Could redirect to a banned page in the future
        return;
      }
      
      // Check if user is not verified
      if (!userStatus.isVerified && userStatus.credentialsStatus === "pending") {
        setLocation("/pending-verification");
        return;
      }
    }
  }, [userStatus, isLoading, setLocation]);

  return {
    userStatus,
    isLoading,
    error,
    isVerified: userStatus?.isVerified === 1 && userStatus?.credentialsStatus === "approved",
    isBanned: userStatus?.isBanned === 1,
    needsOnboarding: userStatus?.isOnboarded === 0,
    needsVerification: userStatus?.isVerified === 0 || userStatus?.credentialsStatus === "pending"
  };
}