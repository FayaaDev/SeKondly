import { useState } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AppHeader from "@/components/app-header";
import BottomNavigation from "@/components/bottom-navigation";
import Feed from "@/pages/feed";
import MyCases from "@/pages/my-cases";
import Notifications from "@/pages/notifications";
import Profile from "@/pages/profile";
import Onboarding from "@/pages/onboarding";
import PendingVerification from "@/pages/pending-verification";
import DoctorProfile from "@/pages/doctor-profile";
import Admin from "@/pages/admin";
import AdminLogin from "@/pages/admin-login";
import NotFound from "@/pages/not-found";
import { VerificationGuard } from "@/components/verification-guard";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Feed} />
      <Route path="/my-cases" component={MyCases} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/profile" component={Profile} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/pending-verification" component={PendingVerification} />
      <Route path="/admin" component={Admin} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/doctor/:doctorId" component={DoctorProfile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [activeTab, setActiveTab] = useState("feed");
  const [location] = useLocation();
  
  const isOnboardingPage = location === "/onboarding";
  const isPendingVerificationPage = location === "/pending-verification";
  const isAdminPage = location.startsWith("/admin");
  const showNavigation = !isOnboardingPage && !isPendingVerificationPage && !isAdminPage;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <VerificationGuard>
          <div className="max-w-md mx-auto bg-white min-h-screen relative overflow-hidden">
            {showNavigation && <AppHeader />}
            <main className={showNavigation ? "pb-20" : ""}>
              <Router />
            </main>
            {showNavigation && <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />}
          </div>
        </VerificationGuard>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
