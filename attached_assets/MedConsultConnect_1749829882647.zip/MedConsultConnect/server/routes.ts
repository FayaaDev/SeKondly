import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCaseSchema, insertCommentSchema, onboardingUserSchema, insertCaseImageSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { createHash } from "crypto";

// Function to hash passwords
function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

// Configure multer for image uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Configure multer for credentials uploads
const credentialsUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/credentials/');
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|jpg|jpeg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only PDF, JPG, JPEG, and PNG files are allowed'));
    }
  }
});

// Support multiple images
const multipleUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB per file
    files: 10 // Maximum 10 images per case
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Extend session interface to include userId and isAdmin
declare module 'express-session' {
  interface SessionData {
    userId?: number;
    isAdmin?: boolean;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user from session
  const getCurrentUser = (req: any) => {
    return req.session?.userId || null;
  };
  
  // Simple user endpoint for debugging
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("User fetch error:", error);
      res.status(500).json({ message: "Failed to fetch user", error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Protected route middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Verification middleware - checks if user is verified
  const requireVerification = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      if (!user.isVerified) {
        return res.status(403).json({ message: "Account pending verification", requiresVerification: true });
      }
      
      if (user.isBanned) {
        return res.status(403).json({ message: "Account suspended" });
      }
      
      next();
    } catch (error) {
      console.error("Verification middleware error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  };

  // Admin middleware - checks if user is admin
  const requireAdmin = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      if (!user.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      next();
    } catch (error) {
      console.error("Admin middleware error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  };

  // Verification middleware - checks if user is verified
  const requireVerified = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      if (user.isVerified !== 1 || user.credentialsStatus !== "approved") {
        return res.status(403).json({ message: "Account verification required" });
      }
      
      next();
    } catch (error) {
      console.error("Verification middleware error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  };

  // Admin login route
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      console.log("Admin login attempt:", username);
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }
      
      // For now, use hardcoded admin credentials
      // In production, this should use proper password hashing
      if (username === "admin" && password === "admin123") {
        // Find the admin user in database
        const adminUser = await storage.getUserByUsername("admin");
        console.log("Found admin user:", adminUser ? `ID ${adminUser.id}` : "not found");
        
        if (adminUser && adminUser.isAdmin) {
          (req.session as any).userId = adminUser.id;
          (req.session as any).isAdmin = true;
          
          console.log("Session set for admin user:", adminUser.id);
          
          return res.json({ 
            message: "Login successful", 
            user: { 
              id: adminUser.id, 
              username: adminUser.username, 
              name: adminUser.name,
              isAdmin: adminUser.isAdmin 
            } 
          });
        }
      }
      
      console.log("Invalid credentials for:", username);
      return res.status(401).json({ message: "Invalid credentials" });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Admin logout route
  app.post("/api/admin/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logout successful" });
    });
  });

  // User login route
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      console.log("User login attempt:", username);
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      console.log("Found user:", user ? `ID ${user.id} - ${user.name}` : "not found");
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Check if user has a password set
      if (!user.password) {
        console.log("User has no password set, allowing login for demo");
      } else {
        // Simple password verification (in production, use proper password hashing)
        if (user.password !== password) {
          console.log("Password mismatch for user:", username);
          return res.status(401).json({ message: "Invalid credentials" });
        }
      }
      
      (req.session as any).userId = user.id;
      console.log("Session set for user:", user.id);
      
      return res.json({ 
        message: "Login successful", 
        user: { 
          id: user.id, 
          username: user.username, 
          name: user.name,
          isVerified: user.isVerified,
          credentialsStatus: user.credentialsStatus
        } 
      });
    } catch (error) {
      console.error("User login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // User logout route
  app.post("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logout successful" });
    });
  });

  // Check admin authentication status
  app.get("/api/admin/auth", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || !user.isAdmin) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          name: user.name,
          isAdmin: user.isAdmin 
        } 
      });
    } catch (error) {
      console.error("Admin auth check error:", error);
      res.status(500).json({ message: "Auth check failed" });
    }
  });

  // Get all cases for feed - requires verification
  app.get("/api/cases", requireVerified, async (req, res) => {
    try {
      const cases = await storage.getCases();
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cases" });
    }
  });

  // Get specific case with details and image gallery - requires verification
  app.get("/api/cases/:id", requireVerified, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const caseData = await storage.getCaseWithImages(id);
      
      if (!caseData) {
        return res.status(404).json({ message: "Case not found" });
      }

      // Increment view count
      await storage.incrementCaseViews(id);
      
      res.json(caseData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case" });
    }
  });

  // Get cases by current user
  app.get("/api/my-cases", async (req, res) => {
    try {
      const userId = getCurrentUser(req);
      const cases = await storage.getCasesByAuthor(userId);
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user cases" });
    }
  });

  // Create new case - requires verification
  app.post("/api/cases", requireVerified, upload.single('image'), async (req, res) => {
    try {
      const userId = getCurrentUser(req);
      
      // Parse form data
      const caseData = {
        ...req.body,
        authorId: userId,
        imageUrl: req.file ? `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}` : undefined
      };

      // Validate data
      const validatedData = insertCaseSchema.parse(caseData);
      
      const newCase = await storage.createCase(validatedData);
      res.status(201).json(newCase);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create case" });
      }
    }
  });

  // Update a case
  app.put("/api/cases/:id", upload.single("image"), async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      // First verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this case" });
      }

      const updateData: any = {};
      
      if (req.body.title) updateData.title = req.body.title;
      if (req.body.history) updateData.history = req.body.history;
      if (req.body.challenges) updateData.challenges = req.body.challenges;
      if (req.body.priority) updateData.priority = req.body.priority;
      
      // Handle image upload if provided
      if (req.file) {
        updateData.imageUrl = `/uploads/${req.file.filename}`;
      }

      // Validate with schema
      const validatedData = insertCaseSchema.partial().parse(updateData);
      
      const updatedCase = await storage.updateCase(caseId, validatedData);
      if (!updatedCase) {
        return res.status(404).json({ message: "Case not found" });
      }

      res.json(updatedCase);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update case" });
      }
    }
  });

  // Delete a case
  app.delete("/api/cases/:id", async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      // Verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this case" });
      }

      const deleted = await storage.deleteCase(caseId);
      if (!deleted) {
        return res.status(404).json({ message: "Case not found" });
      }

      res.json({ success: true, message: "Case deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete case" });
    }
  });

  // Like a case - requires verification
  app.post("/api/cases/:id/like", requireVerified, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.incrementCaseLikes(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to like case" });
    }
  });

  // Get comments for a case - requires verification
  app.get("/api/cases/:id/comments", requireVerified, async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const comments = await storage.getCommentsByCase(caseId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Add comment to case - requires verification
  app.post("/api/cases/:id/comments", requireVerified, async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      const commentData = {
        ...req.body,
        caseId,
        authorId: userId
      };

      const validatedData = insertCommentSchema.parse(commentData);
      const newComment = await storage.createComment(validatedData);
      
      res.status(201).json(newComment);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create comment" });
      }
    }
  });

  // Like a comment
  app.post("/api/comments/:id/like", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.incrementCommentLikes(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to like comment" });
    }
  });

  // Get case image gallery
  app.get("/api/cases/:id/images", async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const images = await storage.getCaseImages(caseId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case images" });
    }
  });

  // Add images to case gallery (file upload)
  app.post("/api/cases/:id/images", multipleUpload.array('images', 10), async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      // Verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to add images to this case" });
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No images provided" });
      }

      const uploadedImages = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const imageData = {
          caseId,
          imageUrl: `/uploads/${file.filename || `temp_${Date.now()}_${i}`}`,
          caption: req.body.captions ? req.body.captions[i] : null,
          orderIndex: i
        };

        const validatedData = insertCaseImageSchema.parse(imageData);
        const newImage = await storage.addCaseImage(validatedData);
        uploadedImages.push(newImage);
      }

      res.status(201).json(uploadedImages);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to upload images" });
      }
    }
  });

  // Add single image to case gallery (JSON endpoint)
  app.post("/api/cases/:id/images/add", async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      // Verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to add images to this case" });
      }

      const imageData = {
        ...req.body,
        caseId
      };

      const validatedData = insertCaseImageSchema.parse(imageData);
      const newImage = await storage.addCaseImage(validatedData);

      res.status(201).json(newImage);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to add image" });
      }
    }
  });

  // Delete case image
  app.delete("/api/cases/:caseId/images/:imageId", async (req, res) => {
    try {
      const caseId = parseInt(req.params.caseId);
      const imageId = parseInt(req.params.imageId);
      const userId = getCurrentUser(req);
      
      // Verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete images from this case" });
      }

      const deleted = await storage.deleteCaseImage(imageId);
      if (!deleted) {
        return res.status(404).json({ message: "Image not found" });
      }

      res.json({ success: true, message: "Image deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete image" });
    }
  });

  // Update image order in gallery
  app.put("/api/cases/:id/images/order", async (req, res) => {
    try {
      const caseId = parseInt(req.params.id);
      const userId = getCurrentUser(req);
      
      // Verify the case exists and user owns it
      const existingCase = await storage.getCase(caseId);
      if (!existingCase) {
        return res.status(404).json({ message: "Case not found" });
      }
      
      if (existingCase.authorId !== userId) {
        return res.status(403).json({ message: "Not authorized to reorder images for this case" });
      }

      const { images } = req.body;
      if (!Array.isArray(images)) {
        return res.status(400).json({ message: "Images array is required" });
      }

      await storage.updateCaseImageOrder(images);
      res.json({ success: true, message: "Image order updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update image order" });
    }
  });

  // Check user verification status
  app.get("/api/user/status", async (req, res) => {
    try {
      const userId = getCurrentUser(req);
      
      // If no session exists, return "not onboarded" to trigger onboarding flow
      if (!userId) {
        return res.json({
          isVerified: 0,
          isBanned: 0,
          credentialsStatus: "pending",
          isOnboarded: 0
        });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        isVerified: user.isVerified,
        isBanned: user.isBanned,
        credentialsStatus: user.credentialsStatus,
        isOnboarded: user.isOnboarded
      });
    } catch (error) {
      console.error("User status error:", error);
      res.status(500).json({ message: "Failed to fetch user status" });
    }
  });

  // Get current user profile
  app.get("/api/profile", async (req, res) => {
    try {
      const userId = getCurrentUser(req);
      console.log('Profile request - Session userId:', (req as any).session?.userId, 'Resolved userId:', userId);
      
      const user = await storage.getUser(userId);
      console.log('Found user:', user ? `ID ${user.id} - ${user.name}` : 'null');
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get user stats
      const userCases = await storage.getCasesByAuthor(userId);
      const stats = {
        cases: userCases.length,
        responses: 182, // Mock data
        helped: 89 // Mock data
      };

      res.json({ ...user, stats });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  // Get notifications for current user
  app.get("/api/notifications", async (req, res) => {
    try {
      const userId = getCurrentUser(req);
      const notifications = await storage.getNotificationsByUser(userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  // Get doctor profile by ID
  app.get("/api/doctors/:id", async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      const doctor = await storage.getUser(doctorId);
      
      if (!doctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }

      // Get case statistics for this doctor
      const doctorCases = await storage.getCasesByAuthor(doctorId);
      const casesShared = doctorCases.length;

      // TODO: Calculate actual helps and favorites from comments and user interactions
      const helps = 0; // Placeholder for actual count of helpful responses
      const favorites = 0; // Placeholder for actual count of favorited cases

      const doctorProfile = {
        ...doctor,
        casesShared,
        helps,
        favorites
      };

      res.json(doctorProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch doctor profile" });
    }
  });

  // Get cases by doctor ID
  app.get("/api/doctors/:id/cases", async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      const cases = await storage.getCasesByAuthor(doctorId);
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch doctor cases" });
    }
  });

  // Complete onboarding - JSON endpoint (no file upload)
  app.post("/api/onboarding", async (req, res) => {
    try {
      // Check if this is a multipart request (has file)
      const isMultipart = req.headers['content-type']?.includes('multipart/form-data');
      
      if (isMultipart) {
        // Handle multipart form data with file upload
        return credentialsUpload.single('credentialsFile')(req, res, async () => {
          await handleOnboarding(req, res);
        });
      } else {
        // Handle JSON data
        await handleOnboarding(req, res);
      }
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create profile" });
      }
    }
  });

  async function handleOnboarding(req: any, res: any) {
    try {
      // Extract data from simplified onboarding form
      const { firstName, lastName, phone, password, boardCertification, fellowship, yearsOfExperience, email } = req.body;
      
      // Combine first and last name
      const name = `Dr. ${firstName} ${lastName}`;
      
      // Generate username from email or names
      const username = email ? email.split('@')[0] : `${firstName.toLowerCase()}.${lastName.toLowerCase()}`;
      
      const userData = {
        username,
        name,
        email: email || `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
        phone,
        password: password ? hashPassword(password) : null, // Hash the password before storing
        specialty: boardCertification, // Use board certification as specialty
        experience: yearsOfExperience,
        boardCertification,
        fellowship: fellowship || null,
        credentialsStatus: "pending",
        credentialsUrl: req.file ? `/uploads/credentials/${req.file.filename}` : null
      };

      // Validate data
      const validatedData = onboardingUserSchema.parse(userData);
      
      const newUser = await storage.createUser(validatedData);
      console.log('Created new user:', newUser.id, newUser.name);
      
      // Automatically log in the newly created user
      (req as any).session.userId = newUser.id;
      console.log('Set session userId to:', newUser.id);
      
      // Save the session to ensure it persists
      (req as any).session.save((err: any) => {
        if (err) {
          console.error('Session save error:', err);
        } else {
          console.log('Session saved successfully');
        }
      });
      
      res.status(201).json({ 
        success: true, 
        message: "Profile created successfully",
        user: newUser 
      });
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create profile" });
      }
    }
  }



  // Admin Routes
  // Get all users for admin management
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Update user status (verify, ban, etc.)
  app.put("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedUser = await storage.updateUserStatus(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true, user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Delete user
  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const success = await storage.deleteUser(userId);
      
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true, message: "User deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Get pending credentials for approval
  app.get("/api/admin/credentials", requireAdmin, async (req, res) => {
    try {
      const pendingUsers = await storage.getPendingCredentials();
      res.json(pendingUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending credentials" });
    }
  });

  // Approve or reject credentials
  app.put("/api/admin/credentials/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { status, rejectReason } = req.body;
      
      const updates: any = { credentialsStatus: status };
      if (status === "rejected" && rejectReason) {
        updates.credentialsRejectReason = rejectReason;
      }
      if (status === "approved") {
        updates.isVerified = 1;
        updates.credentialsStatus = "approved";
      }
      
      const updatedUser = await storage.updateUserStatus(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true, user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: "Failed to update credentials status" });
    }
  });

  // Admin: Get credential document for viewing
  app.get("/api/admin/credentials/:id/document", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.credentialsUrl) {
        return res.status(404).json({ message: "No credentials document found" });
      }
      
      const filePath = path.join(process.cwd(), user.credentialsUrl.replace(/^\//, ''));
      
      // Check if file exists
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "Credentials file not found" });
      }
      
      // Set appropriate headers for file viewing
      const ext = path.extname(filePath).toLowerCase();
      if (ext === '.pdf') {
        res.setHeader('Content-Type', 'application/pdf');
      } else if (['.jpg', '.jpeg'].includes(ext)) {
        res.setHeader('Content-Type', 'image/jpeg');
      } else if (ext === '.png') {
        res.setHeader('Content-Type', 'image/png');
      }
      
      // Send the file
      res.sendFile(filePath);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve credentials document" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
