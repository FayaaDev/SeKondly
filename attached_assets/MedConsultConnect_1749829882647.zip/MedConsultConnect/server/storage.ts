import { 
  users, cases, comments, notifications, caseImages,
  type User, type InsertUser, 
  type Case, type InsertCase, type CaseWithAuthor, type CaseWithImages,
  type Comment, type InsertComment, type CommentWithAuthor,
  type Notification, type InsertNotification,
  type CaseImage, type InsertCaseImage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Case operations
  getCase(id: number): Promise<CaseWithAuthor | undefined>;
  getCaseWithImages(id: number): Promise<CaseWithImages | undefined>;
  getCases(): Promise<CaseWithAuthor[]>;
  getCasesByAuthor(authorId: number): Promise<CaseWithAuthor[]>;
  createCase(caseData: InsertCase): Promise<Case>;
  updateCase(id: number, caseData: Partial<InsertCase>): Promise<Case | undefined>;
  deleteCase(id: number): Promise<boolean>;
  incrementCaseViews(id: number): Promise<void>;
  incrementCaseLikes(id: number): Promise<void>;
  incrementCaseComments(id: number): Promise<void>;
  
  // Case image operations
  getCaseImages(caseId: number): Promise<CaseImage[]>;
  addCaseImage(imageData: InsertCaseImage): Promise<CaseImage>;
  deleteCaseImage(id: number): Promise<boolean>;
  updateCaseImageOrder(images: { id: number; orderIndex: number }[]): Promise<void>;
  
  // Comment operations
  getCommentsByCase(caseId: number): Promise<CommentWithAuthor[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  incrementCommentLikes(id: number): Promise<void>;
  
  // Notification operations
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  updateUserStatus(userId: number, updates: { isVerified?: number; isBanned?: number; credentialsStatus?: string; credentialsRejectReason?: string }): Promise<User | undefined>;
  deleteUser(userId: number): Promise<boolean>;
  getPendingCredentials(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Data already seeded manually via SQL
    // this.seedData();
  }

  private async seedData() {
    try {
      // Check if users already exist
      const existingUsers = await db.select().from(users).limit(1);
      if (existingUsers.length > 0) {
        return; // Data already seeded
      }

      // Create sample users
      const [user1, user2, user3] = await db.insert(users).values([
        {
          username: "sarah.mitchell",
          name: "Dr. Sarah Mitchell",
          email: "sarah.mitchell@clevelandclinic.org",
          phone: "+1 (216) 444-2200",
          specialty: "Cardiology",
          experience: "15 years experience",
          avatar: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
          medicalDegree: "MD (Doctor of Medicine)",
          graduationYear: "2008",
          medicalSchool: "Harvard Medical School",
          boardCertification: "Cardiology",
          certificationYear: "2012",
          fellowship: "Interventional Cardiology",
          fellowshipYear: "2013",
          currentPosition: "Attending Physician",
          hospitalName: "Cleveland Clinic",
          department: "Cardiology Department",
          city: "Cleveland",
          state: "Ohio",
          country: "United States",
          isOnboarded: 1,
          isVerified: 1,
          isBanned: 0,
          isAdmin: 1,
          credentialsStatus: "approved"
        },
        {
          username: "james.rodriguez",
          name: "Dr. James Rodriguez",
          email: "james.rodriguez@mayoclinic.org",
          phone: "+1 (507) 284-2511",
          specialty: "Orthopedics",
          experience: "12 years experience",
          avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
          medicalDegree: "MD (Doctor of Medicine)",
          graduationYear: "2011",
          medicalSchool: "Mayo Medical School",
          boardCertification: "Orthopedics",
          certificationYear: "2016",
          fellowship: "Sports Medicine",
          fellowshipYear: "2017",
          currentPosition: "Senior Attending",
          hospitalName: "Mayo Clinic",
          department: "Orthopedic Surgery",
          city: "Rochester",
          state: "Minnesota",
          country: "United States",
          isOnboarded: 1,
          isVerified: 1,
          isBanned: 0,
          isAdmin: 0,
          credentialsStatus: "approved"
        },
        {
          username: "emily.chen",
          name: "Dr. Emily Chen",
          email: "emily.chen@ucsf.edu",
          phone: "+1 (415) 476-9000",
          specialty: "Neurology",
          experience: "8 years experience",
          avatar: "https://images.unsplash.com/photo-1594824804732-ca8d88af6e2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
          medicalDegree: "MD (Doctor of Medicine)",
          graduationYear: "2015",
          medicalSchool: "UCSF School of Medicine",
          boardCertification: "Neurology",
          certificationYear: "2019",
          fellowship: "Pediatric Neurology",
          fellowshipYear: "2020",
          currentPosition: "Assistant Professor",
          hospitalName: "UCSF Medical Center",
          department: "Neurology",
          city: "San Francisco",
          state: "California",
          country: "United States",
          isOnboarded: 1,
          isVerified: 0,
          isBanned: 0,
          isAdmin: 0,
          credentialsStatus: "pending"
        }
      ]).returning();

      // Create sample cases
      await db.insert(cases).values([
        {
          title: "Complex Arrhythmia in 45-Year-Old Patient",
          history: "45-year-old male presents with intermittent chest palpitations and episodes of dizziness. No previous cardiac history. Recent stress test showed irregular patterns.",
          challenges: "The EKG shows an unusual pattern that doesn't fit typical arrhythmia classifications. I'm particularly concerned about the ST-segment changes.",
          priority: "urgent",
          imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          authorId: user1.id,
          likesCount: 24,
          commentsCount: 12,
          viewsCount: 156
        },
        {
          title: "Unusual Fracture Pattern in Athletic Patient",
          history: "22-year-old professional athlete with complex tibial fracture following training accident. Multiple fragments visible on imaging.",
          challenges: "Considering surgical approach vs conservative management. Patient needs to return to competition within 6 months.",
          priority: "routine",
          imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          authorId: user2.id,
          likesCount: 15,
          commentsCount: 8,
          viewsCount: 89
        },
        {
          title: "Rare Neurological Symptoms in Pediatric Patient",
          history: "8-year-old child presenting with progressive motor weakness and cognitive changes over 3-month period.",
          challenges: "Differential diagnosis challenging. MRI shows subtle changes but unclear etiology. Considering genetic testing.",
          priority: "critical",
          imageUrl: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          authorId: user3.id,
          likesCount: 32,
          commentsCount: 18,
          viewsCount: 203
        }
      ]);

      // Add sample case images for gallery demonstration
      await db.insert(caseImages).values([
        // Images for Case 1: Complex Arrhythmia
        {
          caseId: 1,
          imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Initial 12-lead EKG showing irregular rhythm",
          orderIndex: 0
        },
        {
          caseId: 1,
          imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Holter monitor results - 24 hour analysis",
          orderIndex: 1
        },
        {
          caseId: 1,
          imageUrl: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Echocardiogram showing chamber dimensions",
          orderIndex: 2
        },
        // Images for Case 2: Orthopedic Fracture
        {
          caseId: 2,
          imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "AP X-ray showing tibial fracture pattern",
          orderIndex: 0
        },
        {
          caseId: 2,
          imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Lateral view X-ray",
          orderIndex: 1
        },
        {
          caseId: 2,
          imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "CT scan - 3D reconstruction",
          orderIndex: 2
        },
        // Images for Case 3: Neurological Case
        {
          caseId: 3,
          imageUrl: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Brain MRI - T1 weighted sagittal",
          orderIndex: 0
        },
        {
          caseId: 3,
          imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Brain MRI - T2 weighted axial",
          orderIndex: 1
        },
        {
          caseId: 3,
          imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "FLAIR sequence showing white matter changes",
          orderIndex: 2
        },
        {
          caseId: 3,
          imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
          caption: "Diffusion weighted imaging",
          orderIndex: 3
        }
      ]);
    } catch (error) {
      console.error('Failed to seed data:', error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    try {
      // Validate input parameter
      const numericId = Number(id);
      if (isNaN(numericId) || numericId <= 0) {
        console.error('Invalid user ID provided:', id, 'parsed as:', numericId);
        return undefined;
      }
      
      // Use raw SQL to bypass ORM column mapping issues
      const result = await db.execute(sql`SELECT * FROM users WHERE id = ${id} LIMIT 1`);
      if (result.rows.length === 0) return undefined;
      
      const row = result.rows[0] as any;
      return {
        id: row.id,
        username: row.username,
        name: row.name,
        email: row.email,
        phone: row.phone,
        specialty: row.specialty,
        experience: row.experience,
        avatar: row.avatar,
        medicalDegree: row.medical_degree,
        graduationYear: row.graduation_year,
        medicalSchool: row.medical_school,
        boardCertification: row.board_certification,
        certificationYear: row.certification_year,
        fellowship: row.fellowship,
        fellowshipYear: row.fellowship_year,
        currentPosition: row.current_position,
        hospitalName: row.hospital_name,
        department: row.department,
        city: row.city,
        state: row.state,
        country: row.country,
        isOnboarded: row.is_onboarded,
        isVerified: row.is_verified,
        isBanned: row.is_banned,
        isAdmin: row.is_admin,
        credentialsUrl: row.credentials_url,
        credentialsStatus: row.credentials_status,
        credentialsRejectReason: row.credentials_reject_reason,
        createdAt: row.created_at
      } as User;
    } catch (error) {
      console.error('Error fetching user:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select({
      id: users.id,
      username: users.username,
      name: users.name,
      email: users.email,
      phone: users.phone,
      specialty: users.specialty,
      experience: users.experience,
      avatar: users.avatar,
      medicalDegree: users.medicalDegree,
      graduationYear: users.graduationYear,
      medicalSchool: users.medicalSchool,
      boardCertification: users.boardCertification,
      certificationYear: users.certificationYear,
      fellowship: users.fellowship,
      fellowshipYear: users.fellowshipYear,
      currentPosition: users.currentPosition,
      hospitalName: users.hospitalName,
      department: users.department,
      city: users.city,
      state: users.state,
      country: users.country,
      isOnboarded: users.isOnboarded,
      isVerified: users.isVerified,
      isBanned: users.isBanned,
      isAdmin: users.isAdmin,
      credentialsUrl: users.credentialsUrl,
      credentialsStatus: users.credentialsStatus,
      credentialsRejectReason: users.credentialsRejectReason,
      createdAt: users.createdAt
    }).from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      console.log('Creating user:', insertUser.username);
      
      const userData = {
        username: insertUser.username,
        name: insertUser.name,
        email: insertUser.email,
        phone: insertUser.phone || null,
        password: (insertUser as any).password || null,
        specialty: insertUser.specialty,
        experience: insertUser.experience || '',
        avatar: insertUser.avatar || null,
        boardCertification: insertUser.boardCertification || null,
        certificationYear: insertUser.certificationYear || null,
        fellowship: insertUser.fellowship || null,
        fellowshipYear: insertUser.fellowshipYear || null,
        isOnboarded: 1,
        isVerified: 0,
        isBanned: 0,
        isAdmin: 0,
        credentialsUrl: (insertUser as any).credentialsUrl || null,
        credentialsStatus: (insertUser as any).credentialsStatus || 'pending',
        credentialsRejectReason: (insertUser as any).credentialsRejectReason || null,
        createdAt: new Date()
      };

      const [newUser] = await db.insert(users).values(userData).returning();
      
      console.log('User created successfully:', newUser.id, newUser.username);
      return newUser;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async getCase(id: number): Promise<CaseWithAuthor | undefined> {
    const result = await db.query.cases.findFirst({
      where: eq(cases.id, id),
      with: {
        author: true
      }
    });
    return result;
  }

  async getCases(): Promise<CaseWithAuthor[]> {
    try {
      console.log('Fetching cases with authors...');
      
      // Use raw SQL to handle the join properly
      const result = await db.execute(sql`
        SELECT 
          c.id, c.title, c.history, c.challenges, c.priority, 
          c.image_url as "imageUrl", c.author_id as "authorId", 
          c.created_at as "createdAt", c.likes_count as "likesCount", 
          c.comments_count as "commentsCount", c.views_count as "viewsCount",
          u.id as "author_id", u.username as "author_username", 
          u.name as "author_name", u.email as "author_email", 
          u.specialty as "author_specialty", u.avatar as "author_avatar"
        FROM cases c
        INNER JOIN users u ON c.author_id = u.id
        ORDER BY c.created_at DESC
      `);
      
      console.log(`Found ${result.rows.length} cases`);
      
      const mappedResult = result.rows.map((row: any) => ({
        id: row.id,
        title: row.title,
        history: row.history,
        challenges: row.challenges,
        priority: row.priority,
        imageUrl: row.imageUrl,
        authorId: row.authorId,
        createdAt: row.createdAt,
        likesCount: row.likesCount,
        commentsCount: row.commentsCount,
        viewsCount: row.viewsCount,
        author: {
          id: row.author_id,
          username: row.author_username,
          name: row.author_name,
          email: row.author_email,
          specialty: row.author_specialty,
          avatar: row.author_avatar
        }
      }));
      
      return mappedResult as CaseWithAuthor[];
    } catch (error) {
      console.error('Error fetching cases:', error);
      throw error;
    }
  }

  async getCasesByAuthor(authorId: number): Promise<CaseWithAuthor[]> {
    const result = await db.select({
      id: cases.id,
      title: cases.title,
      history: cases.history,
      challenges: cases.challenges,
      priority: cases.priority,
      imageUrl: cases.imageUrl,
      authorId: cases.authorId,
      createdAt: cases.createdAt,
      likesCount: cases.likesCount,
      commentsCount: cases.commentsCount,
      viewsCount: cases.viewsCount,
      author: {
        id: users.id,
        username: users.username,
        name: users.name,
        email: users.email,
        specialty: users.specialty,
        avatar: users.avatar
      }
    })
    .from(cases)
    .innerJoin(users, eq(cases.authorId, users.id))
    .where(eq(cases.authorId, authorId))
    .orderBy(desc(cases.createdAt));
    
    return result as CaseWithAuthor[];
  }

  async createCase(insertCase: InsertCase): Promise<Case> {
    const [caseRecord] = await db
      .insert(cases)
      .values({
        ...insertCase,
        likesCount: 0,
        commentsCount: 0,
        viewsCount: 0
      })
      .returning();
    return caseRecord;
  }

  async updateCase(id: number, caseData: Partial<InsertCase>): Promise<Case | undefined> {
    const [updatedCase] = await db
      .update(cases)
      .set(caseData)
      .where(eq(cases.id, id))
      .returning();
    return updatedCase || undefined;
  }

  async deleteCase(id: number): Promise<boolean> {
    const result = await db
      .delete(cases)
      .where(eq(cases.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async getCaseWithImages(id: number): Promise<CaseWithImages | undefined> {
    const result = await db.query.cases.findFirst({
      where: eq(cases.id, id),
      with: {
        author: true,
        images: {
          orderBy: caseImages.orderIndex
        }
      }
    });
    return result;
  }

  async getCaseImages(caseId: number): Promise<CaseImage[]> {
    const result = await db.select()
      .from(caseImages)
      .where(eq(caseImages.caseId, caseId))
      .orderBy(caseImages.orderIndex);
    return result;
  }

  async addCaseImage(imageData: InsertCaseImage): Promise<CaseImage> {
    const [image] = await db
      .insert(caseImages)
      .values(imageData)
      .returning();
    return image;
  }

  async deleteCaseImage(id: number): Promise<boolean> {
    const result = await db
      .delete(caseImages)
      .where(eq(caseImages.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async updateCaseImageOrder(images: { id: number; orderIndex: number }[]): Promise<void> {
    for (const image of images) {
      await db
        .update(caseImages)
        .set({ orderIndex: image.orderIndex })
        .where(eq(caseImages.id, image.id));
    }
  }

  async incrementCaseViews(id: number): Promise<void> {
    await db
      .update(cases)
      .set({ 
        viewsCount: sql`views_count + 1`
      })
      .where(eq(cases.id, id));
  }

  async incrementCaseLikes(id: number): Promise<void> {
    await db
      .update(cases)
      .set({ 
        likesCount: sql`likes_count + 1`
      })
      .where(eq(cases.id, id));
  }

  async incrementCaseComments(id: number): Promise<void> {
    await db
      .update(cases)
      .set({ 
        commentsCount: sql`comments_count + 1`
      })
      .where(eq(cases.id, id));
  }

  async getCommentsByCase(caseId: number): Promise<CommentWithAuthor[]> {
    const result = await db.query.comments.findMany({
      where: eq(comments.caseId, caseId),
      with: {
        author: true
      },
      orderBy: comments.createdAt
    });
    return result;
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values({
        ...insertComment,
        likesCount: 0
      })
      .returning();
    
    // Increment case comment count
    await this.incrementCaseComments(insertComment.caseId);
    
    return comment;
  }

  async incrementCommentLikes(id: number): Promise<void> {
    await db
      .update(comments)
      .set({ 
        likesCount: sql`likes_count + 1`
      })
      .where(eq(comments.id, id));
  }

  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    const result = await db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
    return result;
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values({
        ...insertNotification,
        isRead: 0
      })
      .returning();
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: 1 })
      .where(eq(notifications.id, id));
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
    return allUsers;
  }

  async updateUserStatus(userId: number, updates: { isVerified?: number; isBanned?: number; credentialsStatus?: string; credentialsRejectReason?: string }): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId))
      .returning();
    return updatedUser || undefined;
  }

  async deleteUser(userId: number): Promise<boolean> {
    // First delete all related data
    await db.delete(cases).where(eq(cases.authorId, userId));
    await db.delete(comments).where(eq(comments.authorId, userId));
    await db.delete(notifications).where(eq(notifications.userId, userId));
    
    // Then delete the user
    const result = await db.delete(users).where(eq(users.id, userId));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async getPendingCredentials(): Promise<User[]> {
    const pendingUsers = await db
      .select()
      .from(users)
      .where(eq(users.credentialsStatus, "pending"))
      .orderBy(desc(users.createdAt));
    return pendingUsers;
  }
}

export const storage = new DatabaseStorage();
